"""Put the imported HITL sheets on the Altium sheet size (plain Python, editors closed).

The Altium sheets are style 12, Tabloid: 17 x 11 in (431.8 x 279.4 mm). KiCad's Altium import put them on A3
(420 x 297 mm) and flipped y about the A3 height, so the title block ran past the right edge and every y
coordinate sat 2.362 mm off the 2.54 mm grid. This sets the paper to "B" (17 x 11 in, the size named in the title
block) and moves every item up by the difference in height (297.0022 - 279.4 mm), which is exactly the placement
the import would have produced on the right page: y = 279.4 mm - y(Altium). x is untouched; the embedded library
symbols (relative coordinates) are untouched.
"""
import glob
import os
import re
import sys

dst = sys.argv[1]
DY = -(297.0022 - 279.4)
COORD = re.compile(r"\((at|xy|start|end|mid|center)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)")


def num(v):
    s = "%.4f" % v
    s = s.rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def lib_end(t):
    i = t.find("(lib_symbols")
    depth, k = 0, i
    while True:
        c = t[k]
        if c == '"':
            k += 1
            while t[k] != '"':
                k += 2 if t[k] == "\\" else 1
        elif c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return k + 1
        k += 1


for path in sorted(glob.glob(os.path.join(dst, "*.kicad_sch"))):
    t = open(path, encoding="utf-8").read()
    if '(paper "A3")' not in t:
        print(os.path.basename(path), "skipped: paper is not A3")
        continue
    j = lib_end(t)
    head, body = t[:j], t[j:]
    out, pos, n = [], 0, 0
    k = 0
    while k < len(body):                      # copy quoted strings and embedded data untouched
        c = body[k]
        if c == '"':
            e = k + 1
            while body[e] != '"':
                e += 2 if body[e] == "\\" else 1
            k = e + 1
            continue
        if c == "(":
            m = COORD.match(body, k)
            if m:
                out.append(body[pos:m.start()])
                out.append("(%s %s %s" % (m.group(1), m.group(2), num(float(m.group(3)) + DY)))
                pos = k = m.end()
                n += 1
                continue
        k += 1
    out.append(body[pos:])
    head = head.replace('(paper "A3")', '(paper "B")', 1)
    open(path, "w", encoding="utf-8", newline="\n").write(head + "".join(out))
    print(os.path.basename(path), "coordinates moved:", n)
