"""3D models for the HITL board footprints that came from Altium without one (run with KiCad's python).

The model of the same package in KiCad's installed library is copied into <project>/3dmodels and attached to every
board footprint of that type (and to the copy in the project's .pretty library) as ${KIPRJMOD}/3dmodels/<file>.
Placement is not guessed: the library footprint of the model and the Altium footprint are overlaid pad by pad
(rotation in 90 degree steps plus a shift), and the model gets the same rotation and shift.

    python add_models.py <project dir> [--apply]
"""
import math
import os
import shutil
import sys

import pcbnew

dst = sys.argv[1]
APPLY = "--apply" in sys.argv
SHARE = r"C:\Program Files\KiCad\10.0\share\kicad"
IO = pcbnew.PCB_IO_MGR.FindPlugin(pcbnew.PCB_IO_MGR.KICAD_SEXP) or pcbnew.PCB_IO_KICAD_SEXPR()

# Altium footprint (project library, name) -> KiCad library footprint that carries the model of the same package
MAP = {
    ("HEADER_PINS", "CONN_SM04B_JST"): ("Connector_JST", "JST_SH_SM04B-SRSS-TB_1x04-1MP_P1.00mm_Horizontal"),
    # P2, P6: valued SM05B (side entry) but the lands are those of the top-entry BM05B (mounting pads 2.47 mm from
    # the pin row, on the board-edge side), so the model that fits the pads is the vertical one
    ("HEADER_PINS", "CONN5_SM05B-SRSS_JST"): ("Connector_JST", "JST_SH_BM05B-SRSS-TB_1x05-1MP_P1.00mm_Vertical"),
    ("HITL_LIB", "JST_SM08B-SRSS-TB"): ("Connector_JST", "JST_SH_SM08B-SRSS-TB_1x08-1MP_P1.00mm_Horizontal"),
    ("HITL_LIB", "QFP50P900X900X160-48N"): ("Package_QFP", "LQFP-48_7x7mm_P0.5mm"),
}
TOL = {}                                                # stand-ins: a looser pad overlay is accepted
for extra in sys.argv[2:]:
    if extra.startswith("--map="):                      # --map=LIB|NAME|KLIB|KNAME
        a, b, c, d = extra[6:].split("|")
        MAP[(a, b)] = (c, d)
        TOL[(a, b)] = 0.25


def pads(fp):
    """number -> (x, y up) in mm, footprint-local; only numbers that occur once."""
    seen, out = {}, {}
    for p in fp.Pads():
        n = p.GetNumber()
        seen[n] = seen.get(n, 0) + 1
        out[n] = (pcbnew.ToMM(p.GetPosition().x), -pcbnew.ToMM(p.GetPosition().y))
    return {n: v for n, v in out.items() if n and seen[n] == 1}


def rot(v, deg):
    c, s = round(math.cos(math.radians(deg)), 9), round(math.sin(math.radians(deg)), 9)
    return (v[0] * c - v[1] * s, v[0] * s + v[1] * c)


def fit(src, tgt):
    """Rotation (deg, counter-clockwise) and shift that put the pads of src on those of tgt; worst error."""
    common = sorted(set(src) & set(tgt))
    best = None
    for deg in (0, 90, 180, 270):
        r = {n: rot(src[n], deg) for n in common}
        tx = sum(tgt[n][0] - r[n][0] for n in common) / len(common)
        ty = sum(tgt[n][1] - r[n][1] for n in common) / len(common)
        err = max(math.hypot(r[n][0] + tx - tgt[n][0], r[n][1] + ty - tgt[n][1]) for n in common)
        if best is None or err < best[0]:
            best = (err, deg, tx, ty, len(common))
    return best


board = pcbnew.LoadBoard(os.path.join(dst, "HITL.kicad_pcb"))
os.makedirs(os.path.join(dst, "3dmodels"), exist_ok=True)
changed = 0
for (lib, name), (klib, kname) in MAP.items():
    kfp = IO.FootprintLoad(os.path.join(SHARE, "footprints", klib + ".pretty"), kname)
    afp = IO.FootprintLoad(os.path.join(dst, lib + ".pretty"), name)
    km = list(kfp.Models())[0]
    src_model = km.m_Filename.replace("${KICAD10_3DMODEL_DIR}", os.path.join(SHARE, "3dmodels")).replace("/", os.sep)
    if not os.path.isfile(src_model):
        alt = os.path.splitext(src_model)[0] + ".step"
        src_model = alt if os.path.isfile(alt) else src_model
    err, deg, tx, ty, n = fit(pads(kfp), pads(afp))
    ko = rot((km.m_Offset.x, km.m_Offset.y), deg)
    off = (ko[0] + tx, ko[1] + ty, km.m_Offset.z)
    rz = (km.m_Rotation.z - deg) % 360
    rz = rz - 360 if rz > 180 else rz
    tgt_all = [(pcbnew.ToMM(q.GetPosition().x), -pcbnew.ToMM(q.GetPosition().y)) for q in afp.Pads()]
    geo = 0.0                                           # every library pad, numbered or not, must land on a pad
    for q in kfp.Pads():
        v = rot((pcbnew.ToMM(q.GetPosition().x), -pcbnew.ToMM(q.GetPosition().y)), deg)
        geo = max(geo, min(math.hypot(v[0] + tx - t[0], v[1] + ty - t[1]) for t in tgt_all))
    err = max(err, geo)
    refs = sorted(f.GetReference() for f in board.GetFootprints() if str(f.GetFPID().GetLibItemName()) == name
                  and str(f.GetFPID().GetLibNickname()) == lib)
    print(f"{lib}:{name} <- {klib}:{kname}")
    print(f"   pads matched {n}, worst error over all pads {err:.3f} mm, rotate {deg} deg, shift ({tx:.3f}, {ty:.3f}) mm"
          f" | model {os.path.basename(src_model)} exists {os.path.isfile(src_model)} | on board: {refs}")
    if err > TOL.get((lib, name), 0.15) or not os.path.isfile(src_model):
        print("   SKIPPED: pads do not overlay or model file missing")
        continue
    if not APPLY:
        continue
    fname = os.path.basename(src_model)
    shutil.copyfile(src_model, os.path.join(dst, "3dmodels", fname))

    def attach(fp):
        m = pcbnew.FP_3DMODEL()
        m.m_Filename = "${KIPRJMOD}/3dmodels/" + fname
        m.m_Offset = pcbnew.VECTOR3D(off[0], off[1], off[2])
        m.m_Rotation = pcbnew.VECTOR3D(km.m_Rotation.x, km.m_Rotation.y, rz)
        m.m_Scale = pcbnew.VECTOR3D(km.m_Scale.x, km.m_Scale.y, km.m_Scale.z)
        m.m_Show = True
        fp.Models().clear()
        fp.Models().push_back(m)

    for f in board.GetFootprints():
        if str(f.GetFPID().GetLibItemName()) == name and str(f.GetFPID().GetLibNickname()) == lib:
            attach(f)
            changed += 1
    attach(afp)
    IO.FootprintSave(os.path.join(dst, lib + ".pretty"), afp)
if APPLY and changed:
    pcbnew.SaveBoard(os.path.join(dst, "HITL.kicad_pcb"), board)
print("board footprints given a model:", changed, "(applied)" if APPLY else "(dry run)")
