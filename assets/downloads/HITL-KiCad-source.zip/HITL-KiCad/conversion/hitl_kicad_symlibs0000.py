"""Symbol libraries and footprint links for the imported HITL schematics (plain Python, editors closed).

1. Every symbol the Altium import embedded in the sheets (lib_symbols, named <library>:<symbol>) is written to
   <library>.kicad_sym, and sym-lib-table lists those libraries, so the sheets' lib_ids resolve.
2. Each placed symbol's Footprint field becomes the full id of the footprint its designator has on the board
   (<library>:<footprint>, from build_lib.py), so schematic and board agree on footprints.
Nothing else in the sheets is changed: positions, wires, labels, designators and values stay as imported.
"""
import glob
import json
import os
import re
import sys

dst, refmap_path = sys.argv[1], sys.argv[2]
refmap = json.load(open(refmap_path))


def block_end(t, i):
    """Index just after the parenthesised block that starts at t[i] == '(' (quoted strings respected)."""
    depth, k, n = 0, i, len(t)
    while k < n:
        c = t[k]
        if c == '"':
            k += 1
            while t[k] != '"':
                k += 2 if t[k] == "\\" else 1
        elif c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return k + 1
        k += 1
    raise ValueError("unbalanced")


def children(t, start, end):
    """(begin, end) of each direct child block inside t[start:end], which is itself one block."""
    out, k = [], start + 1
    while k < end - 1:
        c = t[k]
        if c == '"':
            k += 1
            while t[k] != '"':
                k += 2 if t[k] == "\\" else 1
            k += 1
        elif c == "(":
            e = block_end(t, k)
            out.append((k, e))
            k = e
        else:
            k += 1
    return out


libs, conflicts, linked, unlinked = {}, 0, 0, []
for path in sorted(glob.glob(os.path.join(dst, "*.kicad_sch"))):
    t = open(path, encoding="utf-8").read()
    top = children(t, 0, block_end(t, 0))
    edits = []
    for a, b in top:
        head = t[a:a + 14]
        if head.startswith("(lib_symbols"):
            for c, d in children(t, a, b):
                m = re.match(r'\(symbol\s+"([^":]+):([^"]+)"', t[c:d])
                if not m:
                    continue
                body = t[c:d].replace(m.group(0), '(symbol "%s"' % m.group(2), 1)
                lib = libs.setdefault(m.group(1), {})
                if m.group(2) in lib and lib[m.group(2)] != body:
                    conflicts += 1
                lib.setdefault(m.group(2), body)
        elif re.match(r"\(symbol\s", head):
            blk = t[a:b]
            r = re.search(r'\(property\s+"Reference"\s+"([^"]*)"', blk)
            f = re.search(r'\(property\s+"Footprint"\s+"([^"]*)"', blk)
            if not r or not f or r.group(1).startswith("#"):
                continue
            if r.group(1) in refmap:
                if f.group(1) != refmap[r.group(1)]:
                    edits.append((a + f.start(1), a + f.end(1), refmap[r.group(1)]))
                linked += 1
            else:
                unlinked.append(r.group(1))
    for s, e, new in sorted(edits, reverse=True):
        t = t[:s] + new + t[e:]
    if edits:
        open(path, "w", encoding="utf-8", newline="\n").write(t)
    print(os.path.basename(path), "footprint fields set:", len(edits))

for name, syms in sorted(libs.items()):
    out = ['(kicad_symbol_lib\n\t(version 20241209)\n\t(generator "kicad_symbol_editor")\n\t(generator_version "9.0")\n']
    for sym in sorted(syms):
        out.append("\t" + syms[sym] + "\n")
    out.append(")\n")
    open(os.path.join(dst, name + ".kicad_sym"), "w", encoding="utf-8", newline="\n").write("".join(out))
rows = "".join('\t(lib (name "%s") (type "KiCad") (uri "${KIPRJMOD}/%s.kicad_sym") (options "") '
               '(descr "Symbols of the Altium library %s, as imported with the HITL schematics"))\n' % (n, n, n)
               for n in sorted(libs))
open(os.path.join(dst, "sym-lib-table"), "w", encoding="utf-8", newline="\n").write(
    "(sym_lib_table\n\t(version 7)\n" + rows + ")\n")
print("symbol libraries", {n: len(s) for n, s in sorted(libs.items())}, "| same name, different body:", conflicts)
print("placed symbols linked to a board footprint:", linked, "| not on the board:", sorted(set(unlinked)))
