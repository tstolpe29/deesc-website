"""Footprint libraries for the imported HITL board (run with KiCad's python).

The Altium project import names every board footprint <Altium library>:<footprint>. This writes one .pretty
library per Altium library name with one copy of each distinct footprint (taken from a top-side, unrotated
instance where there is one), and the project's fp-lib-table. The board file is only read.
"""
import json
import os
import sys

import pcbnew

dst = sys.argv[1]
board = pcbnew.LoadBoard(os.path.join(dst, "HITL.kicad_pcb"))
best = {}
for fp in board.GetFootprints():
    fid = fp.GetFPID()
    nick, name = str(fid.GetLibNickname()), str(fid.GetLibItemName())
    if not name:
        continue
    score = (fp.GetLayer() == pcbnew.F_Cu, abs(fp.GetOrientationDegrees()) < 0.01)
    key = (nick or "HITL_LIB", name)
    if key not in best or score > best[key][0]:
        best[key] = (score, fp)
libs = sorted({k[0] for k in best})
for nick in libs:
    path = os.path.join(dst, nick + ".pretty")
    if not os.path.isdir(path):
        os.makedirs(path)
saved = {}
PLUG = pcbnew.PCB_IO_MGR.FindPlugin(pcbnew.PCB_IO_MGR.KICAD_SEXP) or pcbnew.PCB_IO_KICAD_SEXPR()
for (nick, name), (score, fp) in sorted(best.items()):
    c = pcbnew.Cast_to_FOOTPRINT(fp.Duplicate(False))
    if c.IsFlipped():
        c.Flip(c.GetPosition(), pcbnew.FLIP_DIRECTION_LEFT_RIGHT)
    c.SetOrientationDegrees(0)
    c.SetPosition(pcbnew.VECTOR2I(0, 0))
    c.SetReference("REF**")
    for p in c.Pads():
        p.SetNetCode(0)
    PLUG.FootprintSave(os.path.join(dst, nick + ".pretty"), c)
    saved.setdefault(nick, []).append(name)
rows = "".join(f'\t(lib (name "{n}") (type "KiCad") (uri "${{KIPRJMOD}}/{n}.pretty") (options "") '
               f'(descr "Footprints of the Altium library {n}, as imported with the HITL board"))\n' for n in libs)
open(os.path.join(dst, "fp-lib-table"), "w", encoding="utf-8", newline="\n").write(
    "(fp_lib_table\n\t(version 7)\n" + rows + ")\n")
refmap = {fp.GetReference(): str(fp.GetFPID().GetLibNickname()) + ":" + str(fp.GetFPID().GetLibItemName())
          for fp in board.GetFootprints() if fp.GetReference()}
json.dump(refmap, open(sys.argv[2], "w"), indent=0)
print("libraries", {n: len(v) for n, v in saved.items()})
for n in libs:
    print(n, sorted(os.listdir(os.path.join(dst, n + ".pretty"))))
