import sys, json, pcbnew
b = pcbnew.LoadBoard(sys.argv[1])
out = {}
for f in b.GetFootprints():
    for p in f.Pads():
        out.setdefault(f.GetReference(), {}).setdefault(p.GetNumber(), set()).add(p.GetNetname())
json.dump({r: {n: sorted(v) for n, v in d.items()} for r, d in out.items()}, open(sys.argv[2], "w"), indent=0)
fp = {f.GetReference(): [str(f.GetFPID().GetLibItemName()), f.GetValue()] for f in b.GetFootprints()}
json.dump(fp, open(sys.argv[2] + ".fp.json", "w"))
print("refs", len(out))
