"""Compare a KiCad netlist (.net, s-expression) with the board's pad nets: are the same pins grouped the same way?"""
import collections
import json
import re
import sys

net_path, pcb_json = sys.argv[1], sys.argv[2]
t = open(net_path, encoding="utf-8").read()
i = t.index("(nets")
nets = {}
for block in re.split(r"\n\t\t\(net\b", t[i:])[1:]:
    name = re.search(r'\(name "([^"]*)"\)', block).group(1)
    nets[name] = set(re.findall(r'\(node\s+\(ref "([^"]*)"\)\s+\(pin "([^"]*)"\)', block))
comps = re.findall(r'\(comp\s+\(ref "([^"]*)"\)', t[:i])
pcb = json.load(open(pcb_json))
pg = collections.defaultdict(set)
for ref, pads in pcb.items():
    for num, names in pads.items():
        if ref and names[0]:
            pg[names[0]].add((ref, num))
spins = set().union(*nets.values())
ppins = set().union(*pg.values())
print("netlist: components", len(comps), "nets", len(nets), "pins", len(spins), "| board: nets", len(pg), "pins",
      len(ppins))
print("pins in schematic netlist only:", len(spins - ppins), sorted(spins - ppins)[:12])
print("pins on board (with a net) only:", len(ppins - spins), sorted(ppins - spins)[:12])
common = spins & ppins
a = {frozenset(s & common): n for n, s in nets.items() if s & common}
b = {frozenset(s & common): n for n, s in pg.items() if s & common}
same = set(a) & set(b)
print("pin groups: schematic", len(a), "board", len(b), "identical", len(same))
print("net-name examples:", sorted(nets)[:5], "...", [n for n in sorted(nets) if "SH" in n][:4])
for s in sorted(set(b) - same, key=lambda s: -len(s))[:15]:
    parts = collections.Counter(n for n, x in nets.items() for p in s if p in x)
    print("  board net", b[s], len(s), "pins -> schematic nets", dict(parts))
print("schematic-only groups:", len(set(a) - same))
if "--names" in sys.argv:
    diff = [(a[s], b[s]) for s in same if a[s].lstrip("/") != b[s]]
    print("identical groups whose names differ:", len(diff), sorted(diff)[:40])
