import sys, csv, collections, statistics, pcbnew
board, pnp = sys.argv[1], sys.argv[2]
b = pcbnew.LoadBoard(board)
rows = []
with open(pnp, encoding="latin-1") as f:
    lines = f.read().splitlines()
i = next(k for k, l in enumerate(lines) if l.startswith('"Designator"'))
for r in csv.DictReader(lines[i:]):
    rows.append(r)
ref = {r["Designator"]: r for r in rows}
fps = {f.GetReference(): f for f in b.GetFootprints()}
print("pick&place parts", len(ref), "| KiCad footprints", len(fps))
print("only in Altium P&P:", sorted(set(ref) - set(fps)))
print("only in KiCad:", sorted(set(fps) - set(ref)))
common = sorted(set(ref) & set(fps))
MIL = 0.0254
dx, dy = [], []
for d in common:
    p = fps[d].GetPosition()
    dx.append(pcbnew.ToMM(p.x) - float(ref[d]["Center-X(mil)"]) * MIL)
    dy.append(pcbnew.ToMM(p.y) + float(ref[d]["Center-Y(mil)"]) * MIL)      # KiCad y points down
ox, oy = statistics.median(dx), statistics.median(dy)
bad_pos, bad_layer, bad_rot, bad_fp = [], [], [], []
worst = 0
for d, ex, ey in zip(common, dx, dy):
    err = ((ex - ox) ** 2 + (ey - oy) ** 2) ** 0.5
    worst = max(worst, err)
    if err > 0.02:
        bad_pos.append((d, round(err, 3), ref[d]["Footprint"]))
    f = fps[d]
    side = "TopLayer" if f.GetLayer() == pcbnew.F_Cu else "BottomLayer"
    if side != ref[d]["Layer"]:
        bad_layer.append(d)
    ra = float(ref[d]["Rotation"]) % 360
    rk = f.GetOrientationDegrees() % 360
    if min(abs(ra - rk), 360 - abs(ra - rk)) > 0.01:
        bad_rot.append((d, ra, round(rk, 2), side))
    name = f.GetFPID().GetLibItemName().wx_str() if hasattr(f.GetFPID().GetLibItemName(), "wx_str") else str(f.GetFPID().GetLibItemName())
    if name != ref[d]["Footprint"]:
        bad_fp.append((d, ref[d]["Footprint"], name))
print("offset mm", round(ox, 3), round(oy, 3), "| worst centre error mm", round(worst, 4))
print("position mismatches > 0.02 mm:", len(bad_pos), bad_pos[:12])
print("side mismatches:", bad_layer)
print("rotation mismatches:", len(bad_rot), bad_rot[:12])
print("footprint-name mismatches:", len(bad_fp), bad_fp[:8])
vals = [(d, ref[d]["Comment"], fps[d].GetValue()) for d in common if ref[d]["Comment"] != fps[d].GetValue()]
print("value mismatches:", len(vals), vals[:8])
# holes
holes = collections.Counter()
for t in b.GetTracks():
    if t.GetClass() == "PCB_VIA":
        holes[("PTH", round(pcbnew.ToMM(t.GetDrillValue()), 3), "round")] += 1
for f in b.GetFootprints():
    for p in f.Pads():
        s = p.GetDrillSize()
        if s.x > 0:
            plated = "NPTH" if p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH else "PTH"
            shape = "round" if s.x == s.y else "slot"
            holes[(plated, round(pcbnew.ToMM(min(s.x, s.y)), 3), shape)] += 1
print("KiCad holes:", sum(holes.values()))
for k in sorted(holes):
    print("  ", k, holes[k])
