import sys, re, statistics, pcbnew
b = pcbnew.LoadBoard(sys.argv[1])
out = sys.argv[2]
def excellon(path):
    tools, pts, cur, x, y = {}, [], None, None, None
    for line in open(path, encoding="latin-1"):
        line = line.strip()
        m = re.match(r"T(\d+)F\d+S\d+C([\d.]+)", line)
        if m: tools[int(m.group(1))] = float(m.group(2)) * 25.4; continue
        m = re.fullmatch(r"T(\d+)", line)
        if m: cur = int(m.group(1)); continue
        m = re.fullmatch(r"(?:G0[01])?(?:X(-?\d+))?(?:Y(-?\d+))?", line)
        if m and (m.group(1) or m.group(2)) and cur:
            if m.group(1): x = int(m.group(1)) / 1e5 * 25.4
            if m.group(2): y = int(m.group(2)) / 1e5 * 25.4
            pts.append((round(tools[cur], 3), x, y, line.startswith("G0")))
    return pts
alt = [p for f in ("RoundHoles-Plated", "RoundHoles-NonPlated") for p in excellon(f"{out}/HITL R DRAFT 3 PCB-{f}.TXT")]
kic = []
for t in b.GetTracks():
    if t.GetClass() == "PCB_VIA":
        p = t.GetPosition(); kic.append((round(pcbnew.ToMM(t.GetDrillValue()), 3), pcbnew.ToMM(p.x), -pcbnew.ToMM(p.y)))
for f in b.GetFootprints():
    for pad in f.Pads():
        s = pad.GetDrillSize()
        if s.x > 0 and s.x == s.y:
            p = pad.GetPosition(); kic.append((round(pcbnew.ToMM(s.x), 3), pcbnew.ToMM(p.x), -pcbnew.ToMM(p.y)))
print("round holes: Altium", len(alt), "KiCad", len(kic))
# translation from the 3.25 mm NPTH pair and the 3.2 mm holes (unique sizes)
ax = sorted((x, y) for d, x, y, _ in alt if d in (3.2, 3.25)); kx = sorted((x, y) for d, x, y in kic if d in (3.2, 3.25))
ox = statistics.median(k[0] - a[0] for a, k in zip(ax, kx)); oy = statistics.median(k[1] - a[1] for a, k in zip(ax, kx))
import collections
grid = collections.defaultdict(list)
for d, x, y in kic: grid[(round((x - ox) * 2), round((y - oy) * 2))].append((d, x - ox, y - oy))
worst, miss, sizebad = 0, 0, 0
for d, x, y, _ in alt:
    best = None
    for gx in (-1, 0, 1):
        for gy in (-1, 0, 1):
            for kd, kx_, ky_ in grid.get((round(x * 2) + gx, round(y * 2) + gy), []):
                e = ((kx_ - x) ** 2 + (ky_ - y) ** 2) ** 0.5
                if best is None or e < best[0]: best = (e, kd)
    if best is None or best[0] > 0.01: miss += 1
    else:
        worst = max(worst, best[0]); sizebad += abs(best[1] - d) > 0.002
print("offset mm", round(ox, 4), round(oy, 4), "| Altium holes with no KiCad hole within 0.01 mm:", miss, "| worst error mm", round(worst, 5), "| size mismatches", sizebad)
