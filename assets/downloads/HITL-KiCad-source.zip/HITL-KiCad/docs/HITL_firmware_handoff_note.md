# HITL firmware handoff for Codex

**Board baseline:** `HITL(4).pdf`, SH2-SH7; native source cross-check dated 09 September 2026. This is a hardware contract and implementation plan, not completed or tested firmware. The separate hardware report contains only edit items 01-10. No cover-sheet review is included.

## 1. Source boundary and build profile

Five circuit sources are the `(4).SchDoc` versions: power SH2, MCU SH3, mux SH4, memory SH5, connectors SH7. The latest supplied SH6 native is `(3).SchDoc`. Its R29 is DNI while the current PDF shows 10 kOhm; hardware change 10 proposes a fitted 0-ohm ground strap and requires synchronized source/BOM/PDF. Do not merge the unrelated PODIUM PDB into this board definition. [S01, N2-N7]

Create an explicit board revision/profile in the project. The post-edit profile must record these dependencies:

~2 Capability / hardware option ~2 Required software meaning ~2
~2 --- ~2 --- ~2
~2 Change 06, new R95 fitted ~2 P06's isolated branch has a 10 kOhm pull-down; P06 direction is still not automatically an output. ~2
~2 Change 08, conditional MAG rewire ~2 Set `MAG_COMMON_SIDE=FMU_IN` only after P4=FMU and P6=real GPS/MAG are physically confirmed and the rewire is applied. Otherwise disable MAG emulation pending an approved alternative harness contract. ~2
~2 Change 09, R1 and D1 not fitted ~2 Set `HAS_VBUS_GPIO_SENSE=false`. PA9 cannot report USB attachment in this population. ~2
~2 No external hardware watchdog / bypass ~2 Software must not advertise guaranteed real-path control after HITL power loss or an unresponsive expander. ~2
~2 USB programming use ~2 ROM DFU is the programming path; no application USB data class is requested by this handoff. ~2

The MCU is **STM32H743ZIT6, LQFP144**. The Ethernet controller is an external **W5500 on SPI5**, not an RMII PHY attached to the STM32 Ethernet MAC. SD is **SPI2**, not SDMMC. FRAM is **SPI4**. An I2C2 TCA9535 controls switch selection and RGB. These are actual schematic assignments; firmware policy below is a proposed implementation baseline. [N3-N6]

The eFuses select USB/PDB power autonomously. Their fault/current/enable nodes are not routed to MCU measurement/control pins in this drawing. Do not fabricate software rail-current telemetry, programmable eFuse thresholds, or accessory power switches. External +5 V/+3.3 V connector pins are powered directly from those rails. [N2, N7]

## 2. Project setup and startup sequence

Generate a clean STM32H743ZIT6 project and check in the `.ioc`, toolchain/package versions, linker script, board pin definitions and populated-hardware profile. Use CMSIS/HAL deliberately; RTOS use is optional. Peripheral ownership, timeout handling and deterministic output behavior matter more than the choice of scheduler.

### Stage A - establish a diagnostic state

At reset, use the internal HSI clock to begin diagnostics. The populated HSE is **25 MHz** and LSE is **32.768 kHz**. Set `HSE_VALUE`/`LSE_VALUE` accordingly and configure the HSE as a crystal, not an external bypass clock. Oscillator waits must time out; an unavailable LSE must not hang programming or basic diagnostics. Log the chip revision and clock failure state. [N3; D15]

Do not select 480 MHz merely because the library description says 480 MHz. Confirm the exact silicon revision, applicable errata, supply mode, voltage scale, flash latency, PLL limits and bus/kernel prescalers. Choose the validated operating point needed by measured workload. Derive each timer/SPI/I2C/UART kernel frequency from the actual clock tree; an APB peripheral clock is not always its timer clock. [D15, D16]

Preload output latches before changing GPIO modes: PF6/PE4/PB12 CS high; PG1 Ethernet reset low; PG10 CAN standby high; PC0 indicator low; PB0 buzzer low. Other external chip selects become high before their SPI peripheral is enabled, once peer voltage/power is known. Initially disable timer output enables and UART transmitters on synthetic branches; use high-impedance GPIO states rather than transmitting a guessed neutral value. Maintain SWD access.

### Stage B - establish switch ownership before external traffic

Initialize I2C2 at a conservative **100 kHz** and address U10 at **7-bit 0x20**. Some STM32 HAL calls expect `0x20 << 1`; use the address form expected by the actual API, not a mixture. Apply the explicit register sequence in Section 4 and compare readback. An I2C ACK alone does not prove correct pin state. [N4; D06]

The application should start **unarmed**. Real-path selection is not an instruction to generate actuator commands. Do not initialize synthetic UART/timer outputs and assume all switches have just reset; a warm MCU reset may leave the expander latched in a previous mode. Testing initially requires external actuator harnesses disconnected.

### Stage C - independent peripheral diagnostics

Bring up Ethernet, FRAM, SD and CAN separately with bounded transactions. Report each failure independently. SD absence or an unplugged Ethernet cable must not stop the scheduler or mutate mux selection. No startup error should cause an automatic transition into a synthetic-output mode.

### Stage D - explicit operating authorization

Enable an emulation channel only after its peer pin directions, supply level, timing, protocol configuration and hardware profile are known. The host command must identify the intended test mode. Persist configuration with a version and CRC, but do not restore the last armed state automatically. Settings that are absent or incompatible should prevent that mode from arming.

## 3. MCU pin contract

Physical pin numbers below are for the **144-pin** package, not connector numbers. Named nets are extracted from N3. AF selections were checked against the STM32 alternate-function tables, but a complete CubeMX/clock/DMA build is still required. Software-controlled CS rows deliberately use GPIO rather than hardware NSS. [N3; D15]

~2 MCU port ~2 Pin ~2 Net ~2 Function ~2 AF ~2 Use ~2
~2 --- ~2 --- ~2 --- ~2 --- ~2 --- ~2 --- ~2
~2 PF6 ~2 18 ~2 ETH_SCSN ~2 SPI5 CS ~2 GPIO ~2 W5500 CS, active low ~2
~2 PF7 ~2 19 ~2 ETH_SCLK ~2 SPI5 SCK ~2 5 ~2 W5500 clock ~2
~2 PF8 ~2 20 ~2 ETH_MISO ~2 SPI5 MISO ~2 5 ~2 W5500 -> MCU ~2
~2 PF9 ~2 21 ~2 ETH_MOSI ~2 SPI5 MOSI ~2 5 ~2 MCU -> W5500 ~2
~2 PG0 ~2 56 ~2 ETH_INTn ~2 EXTI / input ~2 GPIO ~2 W5500 INTn, active low ~2
~2 PG1 ~2 57 ~2 ETH_RSTn ~2 Reset output ~2 GPIO ~2 W5500 RSTn, active low ~2
~2 PE2 ~2 1 ~2 SPI4_SCK ~2 SPI4 SCK ~2 5 ~2 FRAM clock ~2
~2 PE5 ~2 4 ~2 SPI4_MISO ~2 SPI4 MISO ~2 5 ~2 FRAM -> MCU ~2
~2 PE6 ~2 5 ~2 SPI4_MOSI ~2 SPI4 MOSI ~2 5 ~2 MCU -> FRAM ~2
~2 PE4 ~2 3 ~2 FRAM_CS ~2 SPI4 CS ~2 GPIO ~2 FRAM CS, active low ~2
~2 PB12 ~2 73 ~2 SD_DATA3 ~2 SPI2 CS ~2 GPIO ~2 SD DAT3/CS, active low ~2
~2 PB13 ~2 74 ~2 SD_CLK ~2 SPI2 SCK ~2 5 ~2 SD clock ~2
~2 PB14 ~2 75 ~2 SD_DATA0 ~2 SPI2 MISO ~2 5 ~2 SD DAT0 -> MCU ~2
~2 PB15 ~2 76 ~2 SD_CMD ~2 SPI2 MOSI ~2 5 ~2 MCU -> SD CMD ~2
~2 PG7 ~2 92 ~2 SD_DET ~2 Card-detect input ~2 GPIO ~2 External pull-up; verify insertion polarity ~2
~2 PB10 ~2 69 ~2 IO_EXP_SCL ~2 I2C2 SCL ~2 4 ~2 Expander bus, MCU controller ~2
~2 PB11 ~2 70 ~2 IO_EXP_SDA ~2 I2C2 SDA ~2 4 ~2 Expander bus, open drain ~2
~2 PG6 ~2 91 ~2 IO_EXP_INT ~2 EXTI / input ~2 GPIO ~2 Expander INT, active low ~2
~2 PA8 ~2 100 ~2 HITL_MAG_SCL ~2 I2C3 SCL ~2 4 ~2 MAG emulation bus; target role ~2
~2 PC9 ~2 99 ~2 HITL_MAG_SDA ~2 I2C3 SDA ~2 4 ~2 MAG emulation bus; open drain ~2
~2 PE9 ~2 60 ~2 HITL_DSHOT1 ~2 TIM1 CH1 ~2 1 ~2 HITL DSHOT1 branch ~2
~2 PE11 ~2 64 ~2 HITL_DSHOT2 ~2 TIM1 CH2 ~2 1 ~2 HITL DSHOT2 branch ~2
~2 PE13 ~2 66 ~2 HITL_DSHOT3 ~2 TIM1 CH3 ~2 1 ~2 HITL DSHOT3 branch ~2
~2 PE14 ~2 67 ~2 HITL_DSHOT4 ~2 TIM1 CH4 ~2 1 ~2 HITL DSHOT4 branch ~2
~2 PB6 ~2 136 ~2 FMU_UART1_TX ~2 USART1 TX ~2 7 ~2 Direct FMU telemetry ~2
~2 PB7 ~2 137 ~2 FMU_UART1_RX ~2 USART1 RX ~2 7 ~2 Direct FMU telemetry ~2
~2 PE8 ~2 59 ~2 HITL_PDB_UART_TX ~2 UART7 TX ~2 7 ~2 PDB synthetic UART branch ~2
~2 PE7 ~2 58 ~2 HITL_PDB_UART_RX ~2 UART7 RX ~2 7 ~2 PDB synthetic UART branch ~2
~2 PE1 ~2 142 ~2 HITL_RF_UART_TX ~2 UART8 TX ~2 8 ~2 RF synthetic UART branch ~2
~2 PE0 ~2 141 ~2 HITL_RF_UART_RX ~2 UART8 RX ~2 8 ~2 RF synthetic UART branch ~2
~2 PD14 ~2 85 ~2 UART8_CTS ~2 UART8 CTS ~2 8 ~2 Test point only; flow control disabled initially ~2
~2 PD15 ~2 86 ~2 UART8_RTS ~2 UART8 RTS ~2 8 ~2 Test point only; flow control disabled initially ~2
~2 PC6 ~2 96 ~2 HITL_GPS_TX ~2 USART6 TX ~2 7 ~2 GPS synthetic UART branch ~2
~2 PC7 ~2 97 ~2 HITL_GPS_RX ~2 USART6 RX ~2 7 ~2 GPS synthetic UART branch ~2
~2 PD0 ~2 114 ~2 CAN_RX ~2 FDCAN1 RX ~2 9 ~2 TCAN1042 RXD ~2
~2 PD1 ~2 115 ~2 CAN_TX ~2 FDCAN1 TX ~2 9 ~2 TCAN1042 TXD ~2
~2 PG10 ~2 125 ~2 CAN_STB ~2 Standby output ~2 GPIO ~2 CAN_STB: high = standby ~2
~2 PB0 ~2 46 ~2 BUZZER ~2 TIM3 CH3 ~2 2 ~2 Q1 buzzer drive, active high ~2
~2 PC0 ~2 26 ~2 LED ~2 LED output ~2 GPIO ~2 D6 blue LED, active high ~2
~2 PA11 ~2 103 ~2 DOUT_N ~2 USB OTG FS DM ~2 10 ~2 USB programming data ~2
~2 PA12 ~2 104 ~2 DOUT_P ~2 USB OTG FS DP ~2 10 ~2 USB programming data ~2
~2 PA9 ~2 101 ~2 USB_VBUS_SNS ~2 VBUS input option ~2 GPIO ~2 No USB presence sensing after hardware change 09 ~2
~2 PA4 ~2 40 ~2 SPI1_CS ~2 SPI1 CS ~2 GPIO ~2 External connector P5 ~2
~2 PA5 ~2 41 ~2 SPI1_SCK ~2 SPI1 SCK ~2 5 ~2 External connector P5 ~2
~2 PA6 ~2 42 ~2 SPI1_MISO ~2 SPI1 MISO ~2 5 ~2 External connector P5 ~2
~2 PA7 ~2 43 ~2 SPI1_MOSI ~2 SPI1 MOSI ~2 5 ~2 External connector P5 ~2
~2 PA15 ~2 110 ~2 SPI3_CS ~2 SPI3 CS ~2 GPIO ~2 External connector P7 ~2
~2 PC10 ~2 111 ~2 SPI3_SCK ~2 SPI3 SCK ~2 6 ~2 External connector P7 ~2
~2 PC11 ~2 112 ~2 SPI3_MISO ~2 SPI3 MISO ~2 6 ~2 External connector P7 ~2
~2 PC12 ~2 113 ~2 SPI3_MOSI ~2 SPI3 MOSI ~2 6 ~2 External connector P7 ~2
~2 PG8 ~2 93 ~2 SPI6_CS ~2 SPI6 CS ~2 GPIO ~2 PG8 is software CS, NOT SPI6 hardware NSS ~2
~2 PG13 ~2 128 ~2 SPI6_SCK ~2 SPI6 SCK ~2 5 ~2 External connector P10 ~2
~2 PG12 ~2 127 ~2 SPI6_MISO ~2 SPI6 MISO ~2 5 ~2 External connector P10 ~2
~2 PG14 ~2 129 ~2 SPI6_MOSI ~2 SPI6 MOSI ~2 5 ~2 External connector P10 ~2
~2 PB8 ~2 139 ~2 I2C1_SCL ~2 I2C1 SCL ~2 4 ~2 External connector J7 ~2
~2 PB9 ~2 140 ~2 I2C1_SDA ~2 I2C1 SDA ~2 4 ~2 External connector J7 ~2
~2 PB5 ~2 135 ~2 I2C1_GPIO ~2 Auxiliary GPIO ~2 GPIO ~2 I2C1_GPIO test point; not serial data ~2
~2 PD12 ~2 81 ~2 I2C4_SCL ~2 I2C4 SCL ~2 4 ~2 External connector J8 ~2
~2 PD13 ~2 82 ~2 I2C4_SDA ~2 I2C4 SDA ~2 4 ~2 External connector J8 ~2
~2 PA0 ~2 34 ~2 UART4_TX ~2 UART4 TX ~2 8 ~2 External connector P12 ~2
~2 PA1 ~2 35 ~2 UART4_RX ~2 UART4 RX ~2 8 ~2 External connector P12 ~2
~2 PD8 ~2 77 ~2 USART3_TX ~2 USART3 TX ~2 7 ~2 External connector P13 ~2
~2 PD9 ~2 78 ~2 USART3_RX ~2 USART3 RX ~2 7 ~2 External connector P13 ~2
~2 PA2 ~2 36 ~2 USART2_TX ~2 USART2 TX ~2 7 ~2 External connector P14 ~2
~2 PA3 ~2 37 ~2 USART2_RX ~2 USART2 RX ~2 7 ~2 External connector P14 ~2
~2 PA13(JTMS-SWDIO) ~2 105 ~2 SWDIO ~2 SWDIO ~2 0 ~2 Debugger reserved ~2
~2 PA14(JTCK/SWCLK) ~2 109 ~2 SWCLK ~2 SWCLK ~2 0 ~2 Debugger reserved ~2
~2 PB3(JTDO/TRACESWO) ~2 133 ~2 SWO ~2 SWO ~2 0 ~2 Optional debugger trace ~2

The spare breakout signals are PF2/PF3/PF4/PF5/PF10, PC1, PC2_C, PC3_C, PC4/PC5, PB1, PF11/PF12, PE12, PF14/PF15. **PC2_C/PC3_C are analog-switch pads**, so a digital-use plan must explicitly handle the relevant internal analog-switch configuration and electrical/speed restrictions. Do not silently treat them as ordinary unrestricted GPIO. PF15 is a spare breakout here, not `HITL2PDB_GPIO`. [N3, N7; D15]

## 4. TCA9535 register and bit contract

A0/A1/A2 are tied low. U10 has a 7-bit address of 0x20. It does not share the external I2C1/I2C4 connectors. Software must have **one owner** for its output shadow registers; LEDs and mux tasks must not overwrite one another's bits. Use locked masked updates rather than whole-port writes from unrelated drivers. [N4]

~2 Register ~2 Address ~2 Initial value ~2 Interpretation ~2
~2 --- ~2 --- ~2 --- ~2 --- ~2
~2 OUTPUT0 ~2 0x02 ~2 0x00 ~2 All real-path selects low; PDB disconnect low; P06 latch low. ~2
~2 OUTPUT1 ~2 0x03 ~2 0x38 ~2 PDB/ESC selects low, ESC disconnect low, R/G/B cathodes high (off). ~2
~2 POLARITY0 ~2 0x04 ~2 0x00 ~2 Input readings not inverted. ~2
~2 POLARITY1 ~2 0x05 ~2 0x00 ~2 Input readings not inverted. ~2
~2 CONFIG0 ~2 0x06 ~2 0x40 ~2 P06 input; other port-0 bits outputs. ~2
~2 CONFIG1 ~2 0x07 ~2 0xC0 ~2 P16/P17 inputs; other port-1 bits outputs. ~2

Write OUTPUT0 and OUTPUT1 before CONFIG0/CONFIG1. Write the two polarity registers explicitly. Read back all six registers and then INPUT0 (0x00) and INPUT1 (0x01). Do not issue a six-byte burst assuming the address pointer walks through every register; use explicitly addressed operations appropriate to this device. The mapping and initial values are board-specific calculations from the native wiring. [N4; D06]

~2 Port.bit ~2 U10 pin ~2 Net ~2 Meaning ~2
~2 --- ~2 --- ~2 --- ~2 --- ~2
~2 P0.0 ~2 4 ~2 GPS_RX_SEL ~2 0 real / 1 HITL ~2
~2 P0.1 ~2 5 ~2 GPS_TX_SEL ~2 0 real / 1 HITL ~2
~2 P0.2 ~2 6 ~2 RF_RX_SEL ~2 0 real / 1 HITL ~2
~2 P0.3 ~2 7 ~2 RF_TX_SEL ~2 0 real / 1 HITL ~2
~2 P0.4 ~2 8 ~2 MAG_SCL_SEL ~2 0 real / 1 HITL ~2
~2 P0.5 ~2 9 ~2 MAG_SDA_SEL ~2 0 real / 1 HITL ~2
~2 P0.6 ~2 10 ~2 HITL2PDB_GPIO ~2 PDB GPIO data branch; input until ownership is defined ~2
~2 P0.7 ~2 11 ~2 PDB_DISCONNECT ~2 1 isolates U9 ~2
~2 P1.0 ~2 13 ~2 PDB_SEL ~2 0 real / 1 HITL ~2
~2 P1.1 ~2 14 ~2 ESC_SEL ~2 0 real / 1 HITL ~2
~2 P1.2 ~2 15 ~2 ESC_DISCONNECT ~2 1 isolates U7 ~2
~2 P1.3 ~2 16 ~2 RGB_R ~2 0 red on ~2
~2 P1.4 ~2 17 ~2 RGB_G ~2 0 green on ~2
~2 P1.5 ~2 18 ~2 RGB_B ~2 0 blue on ~2
~2 P1.6 ~2 19 ~2 Unnamed / R52 ~2 Input with 10 kOhm pull-down ~2
~2 P1.7 ~2 20 ~2 Unnamed / R53 ~2 Input with 10 kOhm pull-down ~2

PG6 receives active-low INT. Latch an event in its ISR, then service the input registers outside the ISR. Define debounce/edge behavior for any external P06 signal. TCA9535 outputs are not general-purpose open-drain outputs; an external bidirectional wire needs a documented ownership strategy before changing P06 into an output. It is unsuitable as a high-rate timing generator. [N4; D06]

The normal baseline above has both disconnect bits low. A separate **bench isolation** state can set OUTPUT0=0x80 and OUTPUT1=0x3C with the same direction masks; that intentionally opens the ESC and PDB paths. Use it only as an explicit operator-selected test state, not a supposedly transparent default. All numeric mode masks need unit tests against this bit table.

## 5. Switch paths and safe mode changes

### Actual paths

~2 Switch ~2 Common/output endpoint ~2 SEL=0 ~2 SEL=1 ~2
~2 --- ~2 --- ~2 --- ~2 --- ~2
~2 U7, DSHOT channels 1-4 ~2 DSHOTn_OUT, ESC-side ~2 FMU_DSHOTn_IN ~2 HITL_DSHOTn ~2
~2 U9, PDB TX/RX/GPIO ~2 PDB_*_IN ~2 PDB_*_OUT ~2 HITL_PDB_UART_TX/RX or P06 GPIO ~2
~2 U8, RF TX/RX ~2 RF_*_IN ~2 RF_*_OUT ~2 HITL_RF_UART_TX/RX ~2
~2 U11, GPS TX/RX ~2 GPS_*_IN ~2 GPS_*_OUT ~2 HITL_GPS_TX/RX ~2
~2 U12 after conditional change 08 ~2 MAG_*_IN, P4 FMU-side ~2 MAG_*_OUT, P6 real device ~2 HITL_MAG_SCL/SDA ~2

U7/U9 use an active-low enable pin: the nets named `*_DISCONNECT` being high disconnect their paths. U8/U11/U12 are the **10-pin DGS** TMUX1072 variant and have no independent enable pin. Do not use the pinout or feature set of another package variant. [N4; D07, D08]

**There is no passive monitoring connection from an unselected HITL branch.** In real mode, the relevant MCU branch is disconnected by the analog switch. Software cannot simultaneously observe both branches by configuring GPIO inputs. A requirement to record live real-path DSHOT/UART/MAG traffic while preserving pass-through needs a separately designed observation path; do not claim it is implemented by this firmware. [N4]

### Transition procedure

For DSHOT/PDB changes: pause generation, reach the required protocol idle state, assert the corresponding disconnect control, confirm the register write, set the selector and configure the new driver's direction/state, then release disconnect when the selected signal is valid. No schedule may temporarily connect two push-pull transmitters. Readback verifies control registers, not an analog continuity test.

For RF/GPS, wait for transmit-complete and an agreed idle interval; update the desired channel pair together through its one port byte. There is no extra global disable pin to call. A packet in progress can be truncated by a selector change, so discard/re-synchronize protocol framing deliberately.

For MAG, update bits 4 and 5 together using mask 0x30 while both lines are idle. Configure the HITL I2C3 peripheral as a **target/slave** when emulating a sensor for an FMU controller. Never start a competing master transaction against the FMU. The exact sensor address, register map, clock-stretch behavior and read/write timing must come from the selected sensor/peer firmware. The board does not contain an onboard IMU/barometer/MAG that supplies those semantics automatically.

## 6. Peripheral implementation plans

### W5500 Ethernet

Use SPI5 mode 0, MSB first, eight-bit transfers and GPIO CS PF6. Start at <=1 MHz for diagnostics and increase only after timing/signal validation. After the Ethernet rail and oscillator are valid, drive PG1 low for a proposed 2 ms reset pulse, release it and wait at least another 2 ms before the first SPI transaction. Extra crystal settling may be necessary. Verify VERSIONR=0x04. [N3, N6; D11]

Integrate the official WIZnet ioLibrary through its SPI/CS and critical-section callbacks. Serialize socket/register access and defer PG0 interrupt handling to a worker. Provide explicit MAC, DHCP/static-IP, port and timeout configuration; do not ship an arbitrary duplicate MAC. A link-down event is not permission to switch hardware modes. Reset/reinitialize the device after a confirmed brownout or repeated bus failures, using a bounded retry policy. [D19; proposed application policy]

### FRAM

U16 is FM25V05-GTR: 64 KiB. Use SPI4 mode 0 initially at <=1 MHz and GPIO CS PE4. Use 16-bit addresses and reject transfers beyond 0xFFFF. Issue the required write-enable command before writes; do not implement flash erase or EEPROM page-program delays as though this were a different memory. [N5; D18]

Define a versioned record layout with bounds, payload length, CRC and a transaction/commit strategy. Boot with conservative defaults when records are corrupt or incompatible. Diagnostic logs and settings must not overwrite one another. A persistent last-mode record is informative only; it does not authorize re-arming after reset.

### SD logging

Implement a SPI-mode block driver on SPI2 with GPIO CS PB12; do not generate an SDMMC pin configuration. Begin at <=400 kHz, supply startup clocks with CS high, perform the standard card-version/capacity initialization, and then select a verified operating clock. Use a suitable SPI SD driver with FatFS or another deliberate filesystem. Validate the actual card types. [N3, N5; implementation proposal]

PG7 has an external pull-up and a socket switch to GND. Confirm whether the physical contact closes or opens on insertion rather than guessing an active polarity. Debounce it and treat errors during a transaction as possible removal. Buffer logs and flush outside the real-time output path; use bounded queues and report dropped records instead of delaying signal generation indefinitely.

### UART and serial emulation

Baud rate, word length, parity, inversion, framing and peer command behavior are **not specified by this schematic**. Do not assume MAVLink, SBUS, CRSF, NMEA or a generic transparent bridge. Store a per-interface configuration, with RX ring buffers, framing/overflow counters and transmit-complete handling. UART8 RTS/CTS are only test-point signals in the drawing; hardware flow control is disabled in the initial profile. [N3, N7]

Define TX/RX by the MCU peripheral and peer direction, not by guessing from an IN/OUT suffix. In sensor emulation, the FMU's TX reaches the HITL RX channel and HITL TX reaches the FMU RX. Confirm that mapping with an actual harness before enabling the transmitter.

### DSHOT

TIM1 channels 1-4 are the proposed waveform resources. Build period and compare values from the actual timer kernel frequency; do not hard-code counts copied from another clock tree. Reserve the DMA/DMAMUX resources and verify all four channels can execute together. DSHOT rate, command framing, checksum and whether bidirectional telemetry is required must be explicit protocol inputs. Do not use GPIO bit-banging in a blocking foreground loop as the default design.

Begin with a disconnected-load waveform test. A bidirectional implementation additionally needs output-to-input turnaround, capture timing and resource verification; it is not obtained merely by marking the hardware mux bidirectional. Input-capture access to real FMU traffic is absent while that MCU branch is switched out. [N3, N4; implementation proposal]

### CAN

Use FDCAN1 PD0/PD1 and PG10 for TCAN1042 standby. Start with standby asserted; load bit timing, filters and the classical-CAN/CAN-FD policy before requesting normal operation. Bit rate and termination depend on the real bus, not the crystal annotation. Make transmit actions explicit and bounded; bus-off recovery must not emit arbitrary actuator traffic. A transceiver standby command is not removal of its +5 V supply. [N3, N6; D21]

### Indicators and buzzer

PC0 drives the blue indicator active high. U10 port-1 bits 3/4/5 drive common-anode RGB cathodes active low; implement status changes through the expander owner, not independent raw I2C writes. PB0 controls Q1 and can use TIM3_CH3 for an externally driven piezo tone. All tone durations must be bounded and nonblocking. [N3, N4]

## 7. Memory, cache and DMA rules

The H743 memory domains are not interchangeable for DMA. DMA1/2 cannot access the CPU's ITCM/DTCM. Select a reachable SRAM region in the linker script for each transfer engine; D2 SRAM is a common DMA1/2 option. **SPI6 uses the D3/BDMA path**, so give it a separate accessible buffer allocation (for example SRAM4 after verifying the selected engine). Do not put all peripheral buffers in one assumed universal section. [D16]

Choose one coherent policy: either carefully maintained cacheable DMA buffers or appropriately configured noncacheable MPU regions. Cacheable buffers need 32-byte alignment and dedicated cache lines, correct TX cleaning before DMA, and correct RX ownership/invalidation before CPU use. Cache-line rounding must not discard unrelated dirty variables. Use the CMSIS cache functions and memory barriers; do not omit post-DMA invalidation simply because startup tests happened to pass. [D17]

Complete the basic polling/interrupt bring-up before enabling caches and multiple DMA pipelines together. Record the linker section, RAM address, alignment, owner and DMA engine for every buffer. Keep ISR work short; SD/filesystem and network operations belong outside waveform-critical ISRs.

## 8. Reset, programming and failure semantics

**MCU reset and whole-board power-on reset are different events.** TCA9535 can retain a previous output selection through MCU NRST. The app must establish a known state through I2C before enabling synthetic outputs, but that is not a hardware-enforced guarantee while the MCU is down. [N4; D06]

For ROM DFU, disconnect external actuator/signal harnesses and cold-cycle the complete board so neither USB nor PDB holds the common rail alive. Use the physical BOOT0/reset entry sequence and verify the option-byte/ROM behavior on the actual device. A simple jump from application code into ROM requires a separately tested deinitialization/clock/interrupt/cache sequence and is not the initial programming method.

The H74xxx ROM probes other interfaces as well as USB. Its SPI4 boot pin group includes PE11-PE14, overlapping this board's DSHOT assignments, and is not the application's FRAM SPI4 group. Do not rely on application mux initialization to execute while ROM owns the MCU. [D09]

With change 09 fitted as specified, the application has no PA9 VBUS-presence input. A later self-powered USB application must obtain a qualified attachment detector before advertising that capability. ROM USB programming and an application USB class are separate requirements.

On host timeout, malformed commands, expander errors or internal deadline violations, stop accepting new test commands, quiesce MCU-generated outputs and mark the mode invalid. Attempt an approved real-path or isolate command only when control communication is healthy. **An unreachable expander means actual mode is UNKNOWN**, not that a software state variable has forced the hardware safe. Power loss makes these muxes high impedance; neither pull-downs nor MCU watchdog firmware creates an unpowered bypass. [D07, D08]

The eFuse latch-off variants may require input power cycling. AUXOFF is not load-side power-good, and its autonomous behavior cannot be repaired by an invented GPIO signal. Log a reset event when observable, but do not invent voltage/current values not measured on the board. [N2; D14]

## 9. Recommended repository and acceptance checks

Separate modules for board pins/profile, clock/startup, I2C expander, mux manager, W5500/network, FRAM storage, SPI SD/filesystem, UART engines, MAG target emulation, DSHOT, CAN and diagnostics. A single command/mode coordinator should own transitions; drivers should return typed error results and support cancellation/timeouts.

A host protocol should include a version, declared length, sequence identifier, integrity check, channel/mode and freshness/deadline information. Enforce range checks before writing hardware. Add an explicit bench arming step and channel permissions. These are proposed interface requirements, not an assertion that a specific host simulator protocol was supplied.

Unit-test every bit mask and transition, SPI framing, record CRC/bounds, command validation, timeout and queue-overflow path. On hardware, demonstrate cold startup, warm MCU reset after a spoofing state, failed expander communication, host-link loss, SD removal, Ethernet reset recovery, real/synthetic endpoint selection and simultaneous timing load. Use logic-analyzer evidence before connecting actuators. Measure USB attach and DFU current with external powered accessories absent; the regulator's current rating is not a measured board load.

Unresolved inputs that must be explicit project configuration or block the affected mode: physical P4/P6 peer contract, PDB-GPIO direction, UART protocols/rates, MAG model/address/register semantics, DSHOT rate/telemetry format, CAN topology/timing, network identity, host protocol, update deadlines and logging throughput. Do not invent these merely to get a successful compile.

## 10. Harness / connector map

These contact maps are extracted from N3/N7, not assumed standard cable pinouts. `NC` means no connected net in the supplied sheet. Power contacts marked +5V/+3.3V are board rail exports unless the connector is J9, the dedicated PDB power input. They are not permission to back-power the board. Separate peer supply outputs from these contacts. J1 is a custom SWD connector, not a standard keyed ARM debug pinout.

~2 Connector ~2 Sheet ~2 Contacts / nets ~2
~2 --- ~2 --- ~2 --- ~2
~2 J1 ~2 SH3 ~2 1=NC; 2=SWCLK; 3=SWDIO; 4=GND; 5=+3.3V; 6=NRST; 7=BOOT0; 8=SWO; P1=GND (mount/shield pad); P2=GND (mount/shield pad) ~2
~2 J9 ~2 SH2 ~2 1=+5V_CONN; 2=GND ~2
~2 P2 ~2 SH7 ~2 1=FMU_DSHOT1_IN; 2=FMU_DSHOT2_IN; 3=FMU_DSHOT3_IN; 4=FMU_DSHOT4_IN; 5=GND; 6=GND (mount/shield pad); 7=GND (mount/shield pad) ~2
~2 P3 ~2 SH7 ~2 1=DSHOT1_OUT; 2=DSHOT2_OUT; 3=DSHOT3_OUT; 4=DSHOT4_OUT; 5=GND; 6=GND (mount/shield pad); 7=GND (mount/shield pad) ~2
~2 P4 ~2 SH7 ~2 1=GND; 2=GPS_RX_IN; 3=GPS_TX_IN; 4=MAG_SCL_IN; 5=MAG_SDA_IN; 6=NC; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P6 ~2 SH7 ~2 1=GND; 2=GPS_RX_OUT; 3=GPS_TX_OUT; 4=MAG_SCL_OUT; 5=MAG_SDA_OUT; 6=+5V; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 J2 ~2 SH7 ~2 1=NC; 2=GND; 3=RF_RX_IN; 4=RF_TX_IN; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 J4 ~2 SH7 ~2 1=+5V; 2=GND; 3=RF_RX_OUT; 4=RF_TX_OUT; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P8 ~2 SH7 ~2 1=GND; 2=PDB_TX_IN; 3=PDB_RX_IN; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P11 ~2 SH7 ~2 1=GND; 2=PDB_TX_OUT; 3=PDB_RX_OUT; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P9 ~2 SH7 ~2 1=GND; 2=FMU_UART1_TX; 3=FMU_UART1_RX; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P12 ~2 SH7 ~2 1=GND; 2=UART4_RX; 3=UART4_TX; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P13 ~2 SH7 ~2 1=GND; 2=USART3_RX; 3=USART3_TX; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P14 ~2 SH7 ~2 1=GND; 2=USART2_RX; 3=USART2_TX; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P5 ~2 SH7 ~2 1=+3.3V; 2=GND; 3=SPI1_SCK via R55 22R; 4=SPI1_CS via R56 22R; 5=SPI1_MISO; 6=SPI1_MOSI via R57 22R; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P7 ~2 SH7 ~2 1=+3.3V; 2=GND; 3=SPI3_SCK via R59 22R; 4=SPI3_CS via R60 22R; 5=SPI3_MISO; 6=SPI3_MOSI via R61 22R; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 P10 ~2 SH7 ~2 1=+3.3V; 2=GND; 3=SPI6_SCK via R63 22R; 4=SPI6_CS via R64 22R; 5=SPI6_MISO; 6=SPI6_MOSI via R65 22R; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 J7 ~2 SH7 ~2 1=+3.3V; 2=GND; 3=I2C1_SDA; 4=I2C1_SCL; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 J8 ~2 SH7 ~2 1=+3.3V; 2=GND; 3=I2C4_SDA; 4=I2C4_SCL; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 J3 ~2 SH7 ~2 1=+5V; 2=CANH_OUT; 3=CANL_OUT; 4=GND; S1=GND (mount/shield pad); S2=GND (mount/shield pad) ~2
~2 J5 ~2 SH7 ~2 1=+3.3V; 2=+5V; 3=PF2; 4=PF3; 5=PF4; 6=PF5; 7=PF10; 8=PC1; 9=PC2_C; 10=PC3_C; 11=GND; 12=GND; 13=GND (mount/shield pad); 14=GND (mount/shield pad) ~2
~2 J6 ~2 SH7 ~2 1=+3.3V; 2=+5V; 3=PC4; 4=PC5; 5=PB1; 6=PF11; 7=PF12; 8=PF14; 9=PF15; 10=PE12; 11=GND; 12=GND; 13=GND (mount/shield pad); 14=GND (mount/shield pad) ~2

For the sensor-emulation contract proposed in hardware change 08: P4 is the FMU connector and P6 is the GPS/MAG connector. Therefore P4.3 reaches FMU RX and P4.2 receives FMU TX; P6.3 receives the real GPS TX and P6.2 goes to real GPS RX. Confirm that proposed cable orientation before applying it. `PDB_GPIO_IN` and `PDB_GPIO_OUT` are on TP22 and TP31, not extra contacts on the three-pin UART connectors. [N7]

## 11. References and provenance

The native geometry extraction is a review aid, not an Altium compiler result. No firmware project, source build, real peer-board package, PCB footprint geometry or bench results were supplied. Conditional firmware/harness choices above must not be mistaken for proven physical wiring on a finished board.

**[S01] Current drawing: HITL(4).pdf.** User upload; SH2-SH7 only. SH1 is excluded.

**[N2] HITL (PWR) SH2(4).SchDoc.** Native power sheet; component parameters, pin numbers and wire geometry.

**[N3] HITL (MCU) SH3(4).SchDoc.** Native MCU sheet; full physical pin allocation and component fields.

**[N4] HITL (MUX) SH4(4).SchDoc.** Native mux sheet; switch endpoints, control bits and pull-ups.

**[N5] HITL (MEMORY) SH5(4).SchDoc.** Native memory sheet; SPI SD and FRAM connections.

**[N6] HITL (INTRFACE 1) SH6(3).SchDoc.** Latest supplied SH6 native is the earlier (3) file, not (4). R29 differs from current PDF.

**[N7] HITL (INTRFACE 2) SH7(4).SchDoc.** Native connector sheet; physical contact and net assignments.

**[D01] Bourns SRP1050WA series.** Page 1: 5R6M and 680M are different inductances and current ratings. https://www.bourns.com/docs/product-datasheets/srp1050wa.pdf

**[D02] Diodes AP64502Q.** Pinout and application component selection; reference input bypassing. https://www.diodes.com/datasheet/download/AP64502Q.pdf

**[D03] Samsung CL21A106KAYNNN family.** Exact E packaging option: 10 uF, 25 V, X5R, 0805, +/-10%. https://product.samsungsem.com/mlcc/CL21A106KAYNNN.do

**[D04] Wurth 150060VS75000.** Page 1: existing orderable part emits green light. https://www.we-online.com/components/products/datasheet/150060VS75000.pdf

**[D05] Wurth 150060BS75000.** Page 1: blue replacement; pin 1 cathode, pin 2 anode. https://www.we-online.com/components/products/datasheet/150060BS75000.pdf

**[D06] TI TCA9535.** Pages 1, 3, 16-22: undriven input bias, register addresses, reset behavior. https://www.ti.com/lit/ds/symlink/tca9535.pdf

**[D07] TI TMUX1072.** DGS 10-pin mapping, selector truth table and powered-off behavior. https://www.ti.com/lit/ds/symlink/tmux1072.pdf

**[D08] TI TMUX1574.** Active-low enable and A/B selection; powered-off isolation. https://www.ti.com/lit/ds/symlink/tmux1574.pdf

**[D09] ST AN2606 bootloader guide.** Rev.70, H74xxx section; USB DFU and bootloader pin-use table on printed p323. https://www.st.com/resource/en/application_note/an2606-stm32-microcontroller-system-memory-boot-mode-stmicroelectronics.pdf

**[D10] ST AN4879 USB hardware guide.** GPIO VBUS detection is distinct from internal analog VBUS sensing. https://www.st.com/resource/en/application_note/an4879-introduction-to-usb-hardware-and-pcb-guidelines-using-stm32-mcus-stmicroelectronics.pdf

**[D11] WIZnet W5500 data sheet v1.1.0.** Printed p9: pin 23 ground requirement; pp10,60: reset and PLL timing. https://docs.wiznet.io/img/products/w5500/W5500_ds_v110e.pdf

**[D12] WIZnet integrated-magnetics reference.** This drawing does NOT specify the previously claimed 10k at pin 23; the pin is shown NC. This review follows D11 pin table. https://docs.wiznet.io/img/products/w5500/w5500_sch_v110_use_mag_.pdf

**[D13] ST ESDAxxPxxx-1U1M TVS family.** Table 4 / p3: ESDA7P120-1U1M; package and polarity drawings. https://www.st.com/resource/en/datasheet/esda7p60-1u1m.pdf

**[D14] TI TPS25947.** May 2026; Option 2 and raw-input transient protection. User also supplied this data sheet. https://www.ti.com/lit/ds/symlink/tps25947.pdf

**[D15] ST STM32H743ZI data sheet.** LQFP144 physical pins, alternate functions and electrical limits. https://www.st.com/resource/en/datasheet/stm32h743zi.pdf

**[D16] ST AN4891 system architecture.** Rev.7: memory domains and DMA access restrictions, pp8,14-16,20-22. https://www.st.com/resource/en/application_note/an4891-stm32h72x-stm32h73x-and-singlecore-stm32h74x75x-system-architecture-and-performance-stmicroelectronics.pdf

**[D17] ST AN4839 cache guidance.** DMA/cache coherency and Cortex-M7 cache-line considerations. https://www.st.com/resource/en/application_note/an4839-level-1-cache-on-stm32f7-series-and-stm32h7-series-stmicroelectronics.pdf

**[D18] Infineon FM25V05-GTR.** 64 KiB SPI FRAM; modes 0/3, no flash-erase operation. https://www.infineon.com/part/FM25V05-GTR

**[D19] WIZnet ioLibrary_Driver.** Official W5500 driver and socket API integration. https://github.com/Wiznet/ioLibrary_Driver

**[D21] TI TCAN1042H-Q1 family.** VIO variant, standby operation and CAN bus requirements. https://www.ti.com/lit/ds/symlink/tcan1042h-q1.pdf

**Input fingerprint:** HITL(4).pdf SHA-256 `34c5cb372cfdfd0145cc53a356523c0c669ebe60bebb532489318ee68cd852f0`.

