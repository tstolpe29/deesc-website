# HITL ROUGH DRAFT 3 - KiCad copy of the Altium project

Made 2026-11-25 with KiCad 10.0 from a copy of the Altium project
`C:\Users\Public\Documents\Altium\1IN1_ENCODER\HITL ROUGH DRAFT 3` (7 SchDoc sheets, `HITL R DRAFT 3 PCB.PcbDoc`).
The Altium folder was only read. Open `HITL.kicad_pro`.

Public copy: the project supervisor's name is removed from the cover sheet, and the cover sheet's firmware-handoff note shows only its heading, as in Altium (Altium clips it to its small frame); the full note is in `docs/HITL_firmware_handoff_note.md`. Nothing else differs from the working project.

## What is here
- `HITL.kicad_pro`, `HITL.kicad_pcb` - board, 6 copper layers (L1..L6), 202 footprints, 1954 track segments,
  458 vias, 14 zones, 3D models embedded in the board file.
- `HITL.kicad_sch` (cover sheet) and six more top-level sheets: PWR SH2, MCU SH3, MUX SH4, MEMORY SH5,
  INTRFACE 1 SH6, INTRFACE 2 SH7. Flat design, as in Altium: same-named net labels connect across sheets.
- `HITL_LIB.kicad_sym`, `FMU_LIB`, `HEADER_PINS`, `SIMPLE_BLDC`, `HITL-altium-import` (power symbols) and
  `sym-lib-table`: 60 symbols, named after the Altium libraries they came from.
- `HITL_LIB.pretty`, `FMU_LIB`, `HEADER_PINS`, `SIMPLE_BLDC`, `FINCH_V2_LIB` and `fp-lib-table`: 36 footprints.
- `HITL_altium_frame.kicad_wks` - sheet border like Altium's (17 x 11 in, zones 1-6 and A-D).
- `3dmodels/` - STEP models added from KiCad's library (see 3D models).
- `plots/` - PDF of every sheet and renders of the board.
- `conversion/` - the scripts used and KiCad's full netlist.

## How it was made
1. KiCad: File > Import Non-KiCad Project > Altium Project, layers auto-matched (L1..L6 -> F.Cu, In1..In4, B.Cu).
2. Power symbols annotated (#PWR01..#PWR0174); no component designator changed.
3. Sheets moved from A3 to B (17 x 11 in, the Altium sheet size) and up by 17.6022 mm, so the title block is on
   the page and every wire is on the 50 mil grid (`hitl_kicad_fixpage0000.py`).
4. Symbol and footprint libraries written from what the import embedded; each symbol's Footprint field set to the
   footprint its designator has on the board (`hitl_kicad_symlibs0000.py`, `hitl_kicad_fplibs0000.py`).

## 3D models
- 183 footprints kept the models Altium had embedded (they are inside `HITL.kicad_pcb`).
- 11 footprints had none in Altium and now use the model of the same package from KiCad's own library, copied into
  `3dmodels/` and placed by overlaying the pads (`conversion/hitl_kicad_models0000.py`): J3, J4, J5, J8, J9
  (SM04B-SRSS-TB), J2 (SM08B-SRSS-TB), U11 (LQFP-48, W5500), P2 and P6 (see below), D1 and D2 (stand-in: a 0603
  diode body; KiCad has no model of the 1.6 x 1.0 mm ST package).
- Still without a model: D5 (MHS110FRGBCT RGB LED, no matching model in KiCad's library), the test pads TP1, TP3,
  TP4 and the four mounting holes.
- **P2 and P6, check the part:** the value says SM05B-SRSS-TB (side entry), but the footprint
  `CONN5_SM05B-SRSS_JST` is the land pattern of the top-entry BM05B-SRSS-TB: mounting pads 2.47 mm from the pin row
  on the board-edge side, like the BM12B footprints of J6 and J7 (the side-entry footprints on this board have
  3.875 mm on the other side). The model shown is the BM05B, because it is the one that fits the pads. This is in
  the Altium design too; nothing was changed.
- Some Altium models carry no colour (the MCU, the Ethernet jack, the USB-C socket) and render white.

## Checked against Altium
- Drill: all 500 round holes within 0.0003 mm of Altium's NC drill files, same sizes; 504 holes in total with the
  4 slots, the same count per tool as Altium's drill report.
- Placement: all 198 parts of the pick-and-place file present, same side, same rotation, same value.
- Netlist: KiCad's full netlist has the same pins on every one of the board's 194 nets; 198 components, same
  values and footprints as the board. 0 unconnected items in KiCad's DRC.
- Sheets compared by eye with `HITL.pdf` (PWR, MCU, cover).

## Known differences
- Text is in KiCad's font, not Times New Roman; bold, italic and underline of the headings are not carried over.
- Altium "Parameter Set" directives are not supported by KiCad's importer and were dropped (one import notice).
- 50 nets without a label keep Altium's names on the board (NetC4_2 ...) and get KiCad's in the schematic
  (Net-(U2-SW) ...). The pins are identical; "Update PCB from Schematic" would rename them on the board.
- KiCad's DRC reports clearance and annular-ring items that Altium's own rule set allowed: only the global
  minimums were imported (10 mil clearance, 4 mil track), not Altium's per-object rules.
- 16 unused Altium "Internal Plane" layer slots were skipped; the board has none.
- The PWR sheet is newer than `HITL.pdf` (edited 31 Oct); KiCad shows the SchDoc as it is now.
- `kicad-cli` exports a netlist per sheet only; the full netlist comes from the schematic editor.
